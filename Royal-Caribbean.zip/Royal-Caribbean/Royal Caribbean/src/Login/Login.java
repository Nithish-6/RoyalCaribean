package Login;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	
		RemoteWebDriver driver;
		public Login(RemoteWebDriver driver)
		{
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
		
		
		
		@FindBy(id= "rciHeaderSignIn")
		WebElement sign_in;
		
		@FindBy(xpath =  "//div[@class='login__container']/a")
		WebElement create_account;
		
		@FindBy(xpath = "//input[@placeholder='First name/Given name']")
		WebElement first_name;
		
		@FindBy(xpath = "//input[@placeholder='Last name/Surname']")
		WebElement last_name;
		
		@FindBy(xpath = "(//div[@class='mat-select-trigger'])[1]")
		WebElement date_month;
		
		@FindBy(id = "mat-option-4")
		WebElement date_month_may;
		
		@FindBy(xpath = "(//div[@class='mat-select-trigger'])[2]")
		WebElement date;
		
		@FindBy(id = "mat-option-17")
		WebElement date_6;
		
		@FindBy(xpath = "//input[@placeholder='Year']")
		WebElement year;
		
		@FindBy(xpath = "(//div[@class='mat-select-trigger'])[3]")
		WebElement country;
		
		@FindBy(id = "mat-option-145")
		WebElement country_india;
		
		@FindBy(xpath = "//input[@placeholder='Email address']")
		WebElement email;
		
		@FindBy(xpath = "//input[@placeholder='Create new password']")
		WebElement password;
		
		@FindBy(xpath = "//span[@class='mat-select-placeholder ng-tns-c31-14 ng-star-inserted']")
		WebElement security_ques;
		
		@FindBy(id = "mat-option-295")
		WebElement seq_que;
		
		
		@FindBy(xpath = "//input[@placeholder='Answer']")
		WebElement security_ans;
		
		@FindBy(xpath = "//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']")
		WebElement policy_accept;
		
		@FindBy(xpath = "//button[@class='mat-royal-button btn-create']")
		WebElement done;
		
		@FindBy(xpath = "//a[@class='header-nav__logo-link ng-star-inserted']")
		WebElement home_page;
		
		
		public void Sign_in_click() 
		{
			sign_in.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
		}
		
		public void Create_account() 
		{
			create_account.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
		}
		
		public void Create_account_details() throws InterruptedException 
		{
			first_name.sendKeys("Ram");
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			last_name.sendKeys("Nithish");
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			date_month.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			date_month_may.click();
//			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
//			date_month.sendKeys(Keys.ARROW_DOWN);
//			date_month.sendKeys(Keys.ARROW_DOWN);
//			date_month.sendKeys(Keys.ARROW_DOWN);
//			date_month.sendKeys(Keys.ARROW_DOWN);
//			date_month.sendKeys(Keys.ARROW_DOWN);
//			date_month.sendKeys(Keys.ENTER);
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			date.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			date_6.click();
//			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
//			date.sendKeys(Keys.ARROW_DOWN);
//			date.sendKeys(Keys.ARROW_DOWN);
//			date.sendKeys(Keys.ARROW_DOWN);
//			date.sendKeys(Keys.ARROW_DOWN);
//			date.sendKeys(Keys.ARROW_DOWN);
//			date.sendKeys(Keys.ARROW_DOWN);
//			date.sendKeys(Keys.ENTER);
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			year.sendKeys("1999");
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			country.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			country_india.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
//			country.sendKeys(Keys.ARROW_DOWN);
//			country.sendKeys(Keys.ENTER);
			driver.manage().timeouts().implicitlyWait(800000, TimeUnit.MILLISECONDS);
			Thread.sleep(1000);
			email.sendKeys("ramkumar06051999@gmail.com");
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			password.sendKeys("Ram@123kumar");
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			security_ques.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			seq_que.click();
//			security_ques.sendKeys(Keys.ARROW_DOWN);
//			security_ques.sendKeys(Keys.ARROW_DOWN);
//			security_ques.sendKeys(Keys.ARROW_DOWN);
//			security_ques.sendKeys(Keys.ENTER);
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			security_ans.sendKeys("Australia");
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			policy_accept.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			done.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			home_page.click();
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
		}
		
	
		
		

}
