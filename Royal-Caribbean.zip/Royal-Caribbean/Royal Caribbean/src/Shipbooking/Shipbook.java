//package Shipbooking;
//
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.remote.RemoteWebDriver;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.PageFactory;
//
//public class Shipbook 
//{
//	
//	RemoteWebDriver driver;
//	public Shipbook(RemoteWebDriver driver)
//    {
//           this.driver =  driver;
//           PageFactory.initElements(driver, this);
//    }
//
//     @FindBy(xpath = "(//div[@class='static_gallery__item']/a)[22]")
//     WebElement Rhapsody_of_seas;
//
//     @FindBy(xpath = "(//div[@class='text_label centercenter'])[4]")
//     WebElement deck_plans;
//
//     @FindBy(xpath = "//select[@class='deck-dropdown']")
//     WebElement deck_dropdown;
//
//     @FindBy(xpath = "(//select[@class='deck-dropdown']/option)[7]")
//     WebElement deck_dropdown_eignt;
//
//     @FindBy(xpath = "//a[@class='storyLine__bookNow__link']")
//     WebElement book_now;
//
//     @FindBy(xpath = "(//div[@class='itinerary-info'])[4]")
//     WebElement western_caribbean_cruise;
//
//     @FindBy(xpath = "//a[@class='itinerary-panel-view-button mat-button']")
//     WebElement View_itinerary_details;
//
//     @FindBy(xpath = "//a[@id='RCCLProductViewSailing_2022-02-05']")
//     WebElement Date_select_ship_travel;
//
//     @FindBy(xpath = "//button[@id='stateroom-continue']")
//     WebElement click_continue;
//
//     @FindBy(xpath = "//button[@id='adult_plus']")
//     WebElement adult_plus;
//
//     @FindBy(xpath = "//button[@id='occupancy-continue']")
//     WebElement adult_continue;
//
//     @FindBy(xpath = "//button[@id='superCategory-interior-select']")
//     WebElement interior_select;
//
//     @FindBy(xpath = "//button[@class='button submit center selectAndContinue text-center']")
//     WebElement select;
//
//     @FindBy(xpath = "//button[@id='location-continue-1']")
//     WebElement Continue;
//
//     @FindBy(xpath = "//button[@id='deck-continue']")
//     WebElement deck_continue;
//
//     @FindBy(xpath = "//button[@class='button submit small-wide']")
//     WebElement submit_continue;
//
////   @FindBy(xpath = "//button[@id='cabin-continue']")
////   WebElement cabin_continue;
//
////   @FindBy(xpath = "//button[@id='pricing-option-cta-non-refundable']")
////   WebElement room_select;
//
//   
//     public void Rhapsody_click()
//     {
//
//           Rhapsody_of_seas.click();
//           driver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);
//     }
//
//     public void Deck_plan_click()
//     {
//
//           deck_plans.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//     }
//
//     public void deck_select()
//     {
//
//           deck_dropdown.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           deck_dropdown_eignt.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           deck_dropdown.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           book_now.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           western_caribbean_cruise.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           View_itinerary_details.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           Date_select_ship_travel.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           click_continue.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           adult_plus.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           adult_continue.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           interior_select.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           select.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           Continue.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           deck_continue.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//           submit_continue.click();
//           driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//
////         cabin_continue.click();
//
////         driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//
////         room_select.click();
//
////         driver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
//     }
//
//}
//
//
