package Function;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import Function.Screenshots;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Testcase.Testcase;
import Login.Login;
//import Shipbooking.Shipbook;

public class Func {
	
	RemoteWebDriver driver;
	Testcase obj;
//	Shipbook ob1;
	Screenshots s = new Screenshots(driver);
	Login ob;
	//static ExtentTest test;
	//static ExtentReports report;
		@BeforeTest
		public void startBrowser() throws IOException
		{
		//report = new ExtentReports(System.getProperty("user.dir")+"\\ExtentReportResults.html");
			//test = report.startTest("ExtentDemo");
			//System.setProperty("webdriver.chrome.driver", "F:\\jars&drivers\\jar_files\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.royalcaribbean.com/");
			driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			s.Screenshot(driver, "Home page");
		
		
			
		}
		
		@Test(priority = 0)
		public void login()
		{
			try
			{
				ob = new Login(driver);
				
				ob.Sign_in_click();
				ob.Create_account();
				ob.Create_account_details();
				s.Screenshot(driver,"Account details");
//				driver.get("https://www.royalcaribbean.com/");
				driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
			//	test.log(LogStatus.PASS, "Sign up successful");
			}
			catch(Exception e)
			{
				
				System.out.println(e);
				//test.log(LogStatus.FAIL, "Sign up Failed");
				
			}
		}
		@Test(priority = 1)
		public void test()
		{
			try
			{
				obj = new Testcase(driver);
				
				
				obj.menu_icon_click();
				obj.Plan_cruise_click();
				obj.Search_port_click();
				obj.Ships_click();
				s.Screenshot(driver, "ship list");
				
//				ob1 = new Shipbook(driver);
				
				obj.Rhapsody_click();
				s.Screenshot(driver, "Rhapsody ship");
				obj.Deck_plan_click();
				Thread.sleep(2000);
				obj.deck_select();
				s.Screenshot(driver, "After deck plan");
				driver.get("https://www.royalcaribbean.com/cruise-ships");
				driver.manage().timeouts().implicitlyWait(80000, TimeUnit.MILLISECONDS);
				//test.log(LogStatus.PASS, "Booking successful");
			}
			catch(Exception e)
			{
				System.out.println(e);
				//test.log(LogStatus.FAIL, "Booking Failed");
			}
		}
		
		@AfterTest
		public void Close()
		{
			//report.endTest(test);
			//report.flush();
			driver.close();
			driver.quit();
			
		}


}
