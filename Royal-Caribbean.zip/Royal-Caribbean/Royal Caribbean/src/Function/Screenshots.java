package Function;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

public class Screenshots {
	
	RemoteWebDriver driver;
	public Screenshots(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void Screenshot(RemoteWebDriver driver, String s) throws IOException 
	{
		
		File source = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File("F:\\Royal-Caribbean1\\Royal-Caribbean\\Screenshots\\Screenshot_"
				+s+".png"));
	}

}
